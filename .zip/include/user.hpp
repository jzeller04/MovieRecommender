#pragma once

class User
{
private:

public:
};

// user should have following functions:
// create user (user info is saved to  file)
// modify/add watched movies
// modify/add genre prefs
// generate genre prefs from list of movies watched
// maybe get list of actors? etc
