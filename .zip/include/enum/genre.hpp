#pragma once\


enum class Genre
{
    Action,
    Adventure,
    Animation,
    Children_s,
    Comedy,
    Crime,
    Documentary,
    Drama,
    Fantasy,
    Film_Noir,
    Horror,
    Musical,
    Mystery,
    Romance,
    Sci_Fi,
    Thriller,
    War,
    Western,
    None,
};