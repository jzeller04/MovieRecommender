# MovieRecommender
A system that takes in user data, and data from the MovieLens data set to recommend users movies to watch using C++.

To run and compile, run "make" and then run the executable "MovieRecommender.exe"
